# 独立使用与复验

本包包含制作合同和可执行检查器，不含游戏主题、美术、完整 RPG-JS 项目或生产后台。交付版本以压缩包文件名和配套 package-check 报告为准；不要在说明正文维护容易过期的第二套版本号。包内含已用于独立章节的参数化 RPG-JS 适配源码、零依赖网格寻路器、平台媒体客户端和渐进媒体恢复内核。接法见 [independent-assembly](independent-assembly.md) 与 [动态房间渐进交付](progressive-room-delivery.md)。需要 Python 3（Pillow、numpy）和 Node >=22.18；可以在自己的虚拟环境安装依赖。RPG-JS 版本与项目构建按当前目标工程锁定，不由本包自动选择。

开始前先复制 `assets/experience-capability-profile.json` 为项目的 `doc/experience-capabilities.json`，如实填写产品画像和模式。发布前运行 `scripts/validate-experience-profile.mjs`；它会阻止长篇/跨次游戏遗漏对话历史、直接移动遗漏脚步、实体 NPC 缺少生活行为、需要跨设备却只用本地存储等静默退化。具体判断见 [体验能力档案](experience-capability-profile.md)。

投影比例、六套 UI、墙门装配、两段式互动、动态房间骨架等脚本只能挡住对应的机械错误，不能替代同事 agent 在独立题材上做完整的美术生产、媒体任务恢复和真实画面复验；这一步完成前不能宣称整个新流程可正式交接。

## 先验证工具包

解包后，在任意工作目录执行（路径替换为本机位置）：

```sh
python /path/to/build-spatial-story-game/scripts/verify-package.py /path/to/build-spatial-story-game.zip --report ./package-check.json
```

它在独立临时目录中执行实际打包脚本，使用简单诊断色块而非游戏美术，检查 12 帧浅色内部保持、去底、源图/报告同名冲突、错误尺寸/空帧/脚点、不覆盖旧输出、独立空间、薄墙及缺失状态。即便子进程 PYTHONOPTIMIZE=1，输入门禁仍须生效。通过不代表目标游戏画面或任何新题材已验收。

## 整理一个已授权的候选

1. 在当前用户授权与图像工具规则允许本地处理时，准备独立 SOURCE.png，保留原图与方向参考。当前工具只支持浅中性色背景、深轮廓主体、均分的 3×4 图集。
2. 只读检查模式/尺寸：`python scripts/inspect-assets.py SOURCE.png`。按素材背景测 neutral-min/chroma-max，按目标图集合同填 foot-x/foot-y。
3. `python scripts/prepare-actor-cutout.py SOURCE.png CANDIDATE.png --neutral-min N --chroma-max N --foot-x X --foot-y Y`。占位符必须换成项目实际值；不复制车厢样本参数作为任意画风默认值。输出还包含 CANDIDATE.json。
4. 深、浅、饱和底检查浅色内部、轮廓与透明缝隙；再用当前 art manifest 运行 check-art-candidates.py。
5. 在目标游戏实际 renderer 下检查手机、四方向、停止、物件接触与同状态大小。通过后才改运行清单；不要把工具自动退出0当作审美批准。

主角不能沿用普通人物的最低检查。先复制 `assets/actor-pose-plan.json`，按 [人物姿态生产合同](actor-pose-production.md) 建立三个方向的 `seed contact → opposite edit` 来源关系并运行 `validate-actor-pose-plan.mjs`；再建立 assembly manifest、运行 `scripts/audit-hero-sheet.py`，按 [主角素材阻断门禁](protagonist-asset-gate.md) 保存 12 格 contact sheet 与两尺寸连续移动证据。局部反射腿部、彼此无关的随机姿态、重复同一运动相或缺少 task/request/SHA 会被拒绝。

进入场景美术前复制 `assets/scene-visual-contract.json`。按 [厚墙房间外框门禁](room-envelope-gate.md) 填北/侧/南独立层与四角覆盖关系，按 [家具方向配比合同](furniture-orientation-mix.md) 填每件家具方向、用途、功能区、footprint 面积和碰撞，再运行 `validate-scene-visual-contract.mjs`。没有这份清单时，不允许仅凭漂亮的烘焙底图或若干 45° 家具宣称房间美术完成。

主角通过后，建立 version 1 actor-roster manifest，运行 `scripts/audit-actor-roster.py ACTOR-ROSTER.json --root GAME_ROOT --require-accepted`。每名 NPC 必须保存平台来源、运行图集与显示尺寸，并提供和主角相邻、同镜头倍率、覆盖 down/side/up 的真实 renderer 证据。该检查会拒绝整组比例漂移和缺证据，但不会自动判断脸、年龄、服装、描边或动作是否自然。

## 接一个可交谈实体

共享布局统一渲染脚点、hitbox、接近点和场景权限；实体定义与状态图注册完整。首次介绍由作者规则完成，成功后才解锁姓名和人物列表。当前角色的记忆只读该角色实际已收报告，不继承其他人的联络内容。

把提示绑定到具体线索来源，把角色职责绑定到当前可执行动作；仅要求模型“别编造”不够。留守顾问可以告诉玩家去哪，不应说自己将替玩家开柜、拿物或安装。模型语义审查也会误判或漏判，对实测反例增加窄范围规则或作者控制的回退，并说明规则不覆盖所有自然语言。未介绍人物的自由文本优先返回无姓名的确定性观察，通过正常见面动作介绍。

从真实运行配置导出 world manifest，运行 `node scripts/validate-world.mjs world-manifest.json /asset/root`。可达检查扫描网格步进的完整碰撞路径；它只验证静态矩形空间，不能证明引擎运动、动画或动态碰撞。新增实体仍要回归原主线、旧位置迁移与丢回执恢复。

后续实证记录放在目标项目 doc/requirements.md、visual.md、technical.md 和 QA 文件中。技能只沉淀跨项目合同与可复现工具，不复制一个游戏的标题或场景坐标。

## 复用移动模块

移动与切帧接法见 [mobile-motion](mobile-motion.md)。复制 `assets/distance-motion.ts` 到目标源码并由实际游戏直接消费；用 `node scripts/verify-motion.mjs /path/to/copied-module.ts` 检查目标副本。步速、步幅、纹理名由目标游戏适配层持有，不复制样本110/55为通用默认。独立包自检同时运行这组无图像/无引擎依赖的测试。

## 深度与生产增量

独立物件排序接法见 [depth-rendering](depth-rendering.md)，服务、有限观察模型、回执恢复和备份边界见 [production-evidence](production-evidence.md)。v1.10 新增的是已经实测的决策合同与参考定位，不声称新提供整套云端后台或上游引擎补丁。

## 2026-09 独立金融题材实测边界
新项目在未读取旧游戏源码的情况下完成四场景调查，但作者熟悉历史失败，因此属于带经验复用，不能冒充陌生同事盲测。发现并回写了能力模板默认虚报、同任务多帧误拒、侧门地板覆盖人物、首次介绍选项挤出首屏、结局证据快照问题。脚本包通过不等于生成素材一次合格；人物仍可能需要多轮平台生成与实际 renderer 复验。
