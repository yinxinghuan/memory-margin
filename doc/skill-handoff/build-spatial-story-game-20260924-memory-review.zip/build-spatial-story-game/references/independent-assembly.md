# 独立章节装配实证（v1.9）

适用于已有确定的正交场景与单人作者规则、需要新建或迁移真实 RPG-JS renderer 的项目。它是 `build-spatial-story-game` 直接移动空间层的默认实现合同，不再是可选增强。不是后端/多人模板；生产身份、云存档与 LLM 必须另验。

## 禁止的降级路径

- 不得为了更快做出画面，改用 React 中的单个 Canvas2D 循环逐帧绘制地面、墙体、全部家具与人物。
- 不得在每帧从高分辨率源图缩放静态场景。地面、墙、家具和图集必须由 Pixi/CanvasEngine 作为已加载纹理持有，静态视觉由地图层或 RPG 事件承担。
- 不得把家具 PNG 的透明画布或整张组合图外接矩形直接当碰撞。视觉锚点、深度脚点和一个或多个落地 footprint 分别记录，并从同一场景清单导出。
- React/DOM 继续负责 UI 不构成绕过 RPG renderer 的理由。迁移范围应是空间层：地图、纹理、人物、家具、镜头、移动、深度与转场；故事 reducer、对话和存档可以原样保留。

## 可复用模块
将 assets 中 distance-motion.ts、world.ts、rpg-space.ts 放到目标同一目录。world.ts 是纯矩形碰撞与寻路，rpg-space.ts 是引擎适配器。题材、角色、动作、图集、设备、UI、存档均由目标工程提供。

`createRpgSpace({world,host,scene,position,speed,stride,poses,sheet,onPosition,onDestination,onReady,onError})`。world 类型见 world.ts；sheet 使用锁定引擎版本的 spritesheet 配置；必须包含 stand 纹理及 poses 中的静态姿态。onReady 后才开放输入。

- host 必须为 #rpg，父元素按世界宽高比例显示；host 设世界逻辑宽高、absolute、transform-origin:top left、pointer-events:none。背景、碰撞、热点必须消费同一场景清单。
- `public/map/<scene-id>.tmx` 和关联 TSX/PNG 必须存在。每张 TMX 必须保留至少一个 `objectgroup`（通常为 `collision`），即使共享布局模型承担碰撞、该层为空也不能删除；实测缺少对象层会让 RPGJS 完成地图握手却不创建玩家和事件的 Pixi 显示节点。Tiled client 默认 ./map；导出时从实际 world 的 interior 与 obstacles 得到障碍，不能另抄坐标。透明地砖 PNG 必须与 TSX 宣称的像素尺寸相符。
- options 的 speed / stride / poses / sheet 由目标项目设定，不复制验证章节的数值当通用默认。
- runtime 提供 position、scene、renderedScene、move、walkTo、pause、restore；成功动作提交后，使用权威返回的 scene/position 调用 restore。禁止先改 UI 地图名再假定引擎已转场。
- 一页仅创建一个引擎实例，当前不提供完整引擎销毁/热重挂载合同；不要放进会双挂载的 StrictMode 或路由卸载循环。

## 固定版本与构建实证
独立样本 signal-room-story-lab 使用 @rpgjs/client/server/tiledmap 5.0.0-beta.34、@rpgjs/common beta.31、CanvasEngine/compiler 2.2.0、Pixi8、Vite8、Node22.22.2，实际 lockfile 固定传递依赖。Vite 使用 canvasengine 默认 compiler 插件、base './'，dedupe @signe/reactive、@signe/di、canvasengine、pixi.js、@rpgjs/common。该组合 npm ci 需 .npmrc legacy-peer-deps=true。其他版本不能假定兼容。

## 真实失败与修复
1. **握手死锁**：onConnected 内 await 客户端地图加载会阻止连接钩子返回，客户端无法完成 join。让钩子在 changeMap 后返回，异步等待 onJoinMap + onAfterLoading 后才 onReady。
2. **缺少中间状态**：先列完整规则状态，再生成图。电池“空槽 / 已装未通电 / 已通电”不能压成两张；引导开关不能用电话图片冒充。
3. **呈现变形**：图集裁切后保持实际比例，地图与特写均不能用非等比拉伸破坏已选视角。
4. **旧回执覆盖新进度**：幂等回执是历史结果。恢复 pending 后另读最新权威 head，不能直接用旧 receipt 覆盖已发生的后续进度。
5. **存储隔离漏项**：IndexedDB 与 localStorage 一样受同 origin 影响。storage-scope.ts 从正式 URL UUID 得到命名空间；Pages/本地才使用源码 UUID。

## 复验
`node scripts/verify-space.mjs [目标模块目录]` 使用不同于样本的诊断空间检查非网格点、薄墙、路径运动和 Remix 隔离；无游戏/浏览器依赖。这不测试 RPG-JS 本身。

真实 renderer 需另外走完：启动 → 断言 TMX `objectgroup` → 断言房间玩家/事件已同步 → 断言 Pixi 显示树出现玩家与事件纹理 → 错误动作不消耗 → 正确状态变化 → 相邻地图 → 刷新恢复 → 完成 → 回到原图继续。记录手机构图；合成 fps 测试不是 iPhone 真机测量。样本真实浏览器已完成这条路径；UI 审美深化按用户要求后置。
