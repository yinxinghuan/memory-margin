import fs from 'node:fs';

const file=process.argv[2];
if(!file){console.error('Usage: node validate-scene-visual-contract.mjs SCENE-VISUAL-CONTRACT.json');process.exit(2)}
let data;try{data=JSON.parse(fs.readFileSync(file,'utf8'))}catch(error){console.error('FAIL: '+error.message);process.exit(2)}
const errors=[];const fail=message=>errors.push(message);
if(data.version!==1)fail('version must be 1');
if(!Array.isArray(data.rooms)||!data.rooms.length)fail('rooms must be non-empty');
for(const room of data.rooms||[]){
 const prefix=room.id||'room';const envelope=room.envelope||{};
 if(envelope.mode!=='thick-orthographic')fail(`${prefix}: envelope mode must be thick-orthographic`);
 const assets=envelope.assets||{},assetIds=['floor','northWall','sideWall','southForeground'].map(key=>assets[key]);
 if(assetIds.some(value=>!value))fail(`${prefix}: floor, northWall, sideWall and southForeground assets are required`);
 if(new Set(assetIds.filter(Boolean)).size!==assetIds.filter(Boolean).length)fail(`${prefix}: room envelope assets must use independent IDs`);
 const dims=envelope.dimensions||{};for(const key of ['northFaceHeight','sideThickness','southForegroundHeight'])if(!(Number(dims[key])>0))fail(`${prefix}: ${key} must be positive`);
 if(JSON.stringify(envelope.layerOrder)!==JSON.stringify(['north','side','actors','south']))fail(`${prefix}: layerOrder must be north, side, actors, south`);
 const expected={northWest:'side-over-north',northEast:'side-over-north',southWest:'south-over-side',southEast:'south-over-side'};
 for(const [corner,value] of Object.entries(expected))if(envelope.corners?.[corner]!==value)fail(`${prefix}: ${corner} must be ${value}`);
 const requiredFeatures={north:['cap','face','trim','floor-shadow'],side:['cap','inner-seam'],south:['cap','face','trim']};
 for(const [part,features] of Object.entries(requiredFeatures))for(const feature of features)if(!envelope.features?.[part]?.includes(feature))fail(`${prefix}: ${part} missing ${feature}`);
 const furniture=Array.isArray(room.furniture)?room.furniture:[];
 const freestanding=furniture.filter(item=>['axis-aligned','diagonal-45'].includes(item.orientation));
 const diagonal=freestanding.filter(item=>item.orientation==='diagonal-45');
 if(freestanding.length&&!freestanding.some(item=>item.orientation==='axis-aligned'))fail(`${prefix}: axis-aligned furniture must remain the room majority`);
 for(const item of diagonal){
  if(item.role!=='accent')fail(`${prefix}/${item.id}: diagonal-45 furniture must be accent, never anchor`);
  if(!['rects','polygon'].includes(item.collision))fail(`${prefix}/${item.id}: diagonal-45 collision must use rects or polygon`);
 }
 const zoneCounts=new Map();for(const item of diagonal){const zone=item.zone||'unassigned';zoneCounts.set(zone,(zoneCounts.get(zone)||0)+1)}for(const [zone,count] of zoneCounts)if(count>1)fail(`${prefix}/${zone}: at most one diagonal-45 furniture item per functional zone`);
 const totalArea=freestanding.reduce((sum,item)=>sum+Number(item.footprintArea||0),0),diagonalArea=diagonal.reduce((sum,item)=>sum+Number(item.footprintArea||0),0);
 const exception=room.diagonalException?.userApproved===true;
 if(!exception&&freestanding.length&&diagonal.length/freestanding.length>1/3+1e-9)fail(`${prefix}: diagonal-45 count exceeds one third`);
 if(!exception&&totalArea>0&&diagonalArea/totalArea>.25+1e-9)fail(`${prefix}: diagonal-45 footprint exceeds one quarter`);
 const evidence=Array.isArray(room.evidence)?room.evidence:[];
 for(const viewport of ['390x844','320x568'])if(!evidence.some(item=>item.viewport===viewport&&item.renderer==='actual'&&item.corners===true&&item.southOcclusion===true))fail(`${prefix}: missing thick-wall actual renderer evidence at ${viewport}`);
}
if(errors.length){for(const error of errors)console.error('FAIL: '+error);process.exit(1)}
console.log(JSON.stringify({passed:true,rooms:data.rooms.length}));
