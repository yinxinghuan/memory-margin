#!/usr/bin/env node
import fs from 'node:fs'

const files=process.argv.slice(2)
if(!files.length){console.error('usage: validate-rpg-map.mjs <map.tmx...>');process.exit(2)}
const errors=[]
for(const file of files){
 let source=''
 try{source=fs.readFileSync(file,'utf8')}catch(error){errors.push(`${file}: ${error.message}`);continue}
 if(!/<map\b/i.test(source))errors.push(`${file}: missing map root`)
 if(!/<layer\b/i.test(source))errors.push(`${file}: missing tile layer`)
 if(!/<objectgroup\b/i.test(source))errors.push(`${file}: missing objectgroup; RPGJS may join the room without creating player/event display nodes`)
}
if(errors.length){for(const error of errors)console.error(`FAIL: ${error}`);process.exit(1)}
console.log(JSON.stringify({passed:true,maps:files.length}))
