#!/usr/bin/env python3
"""Audit provenance and perceived scale for one hero plus an NPC actor roster."""
import argparse,hashlib,json,sys
from pathlib import Path
from PIL import Image

p=argparse.ArgumentParser();p.add_argument('manifest',type=Path);p.add_argument('--root',type=Path,default=Path('.'));p.add_argument('--require-accepted',action='store_true');a=p.parse_args()
errors=[]
try:m=json.loads(a.manifest.read_text())
except Exception as exc:print(f'FAIL: cannot read manifest: {exc}',file=sys.stderr);sys.exit(1)
def check(ok,message):
 if not ok:errors.append(message)
check(m.get('version')==1,'manifest version must be 1')
check(m.get('sourceService')=='AlterU Media Service','sourceService must be AlterU Media Service')
if a.require_accepted:check(m.get('status')=='accepted','actor roster status must be accepted')
actors=[m.get('hero') or {},*(m.get('actors') or [])];ids=[];metrics={}
for actor in actors:
 ident=actor.get('id');ids.append(ident)
 check(bool(ident), 'every actor needs an id')
 check(bool(actor.get('requestIds')) and bool(actor.get('taskIds')),'every actor needs requestIds and taskIds')
 try:
  path=a.root/actor['path'];raw=path.read_bytes();check(hashlib.sha256(raw).hexdigest()==actor.get('sourceSha256'),f'{ident}: source SHA mismatch')
  image=Image.open(path).convert('RGBA');x,y,w,h=actor.get('cell',[0,0,image.width,image.height]);crop=image.crop((x,y,x+w,y+h));box=crop.getchannel('A').point(lambda value:255 if value>200 else 0).getbbox();check(box is not None,f'{ident}: no opaque silhouette')
  display=actor.get('displayWorld');check(isinstance(display,list) and len(display)==2,f'{ident}: displayWorld must be [w,h]')
  if box and isinstance(display,list) and len(display)==2:
   sx,sy=display[0]/w,display[1]/h;check(abs(sx-sy)/max(sx,sy)<=.02,f'{ident}: actor cell stretched in world')
   metrics[ident]={'height':(box[3]-box[1])*sy,'width':(box[2]-box[0])*sx}
 except Exception as exc:errors.append(f'{ident}: cannot inspect actor: {exc}')
check(len(ids)==len(set(ids)),'actor ids must be unique')
hero=(m.get('hero') or {}).get('id');base=metrics.get(hero);height_tolerance=m.get('adultHeightTolerance',.12);width_range=m.get('adultWidthRatioRange',[.65,1.35])
if base:
 for ident,value in metrics.items():
  if ident==hero:continue
  check(abs(value['height']/base['height']-1)<=height_tolerance,f'{ident}: visible height differs from hero by more than {height_tolerance:.0%}')
  ratio=value['width']/base['width'];check(width_range[0]<=ratio<=width_range[1],f'{ident}: visible width / hero width {ratio:.2f} outside {width_range}')
evidence={item.get('actorId'):item for item in m.get('evidence',[])}
for ident in ids[1:]:
 item=evidence.get(ident);check(bool(item),f'{ident}: missing adjacent hero comparison evidence')
 if item:
  check(item.get('heroAdjacent') is True,f'{ident}: evidence must place actor adjacent to hero')
  check(item.get('viewport') in [[390,844],[320,568]],f'{ident}: evidence viewport must be a target phone size')
  check(set(item.get('directions',[]))>={'down','side','up'},f'{ident}: evidence must cover down/side/up')
  check((a.root/item.get('path','')).is_file(),f'{ident}: evidence file missing')
for error in errors:print('FAIL: '+error,file=sys.stderr)
if errors:sys.exit(1)
print(json.dumps({'passed':True,'actors':len(actors),'hero':hero,'status':m.get('status')}))
