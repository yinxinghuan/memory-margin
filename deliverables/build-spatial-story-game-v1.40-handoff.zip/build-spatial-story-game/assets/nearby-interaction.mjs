/** Stable nearby focus for an already filtered, authoritative scene projection. */
export function stableNearby(entities,position,isNear,previousId,preferredId,hysteresis=8){
 const candidates=entities
  .filter(entity=>isNear(entity,position))
  .map(entity=>({entity,distance:Math.hypot(entity.approach.x-position.x,entity.approach.y-position.y)}))
  .sort((a,b)=>a.distance-b.distance)
 const preferred=candidates.find(item=>item.entity.id===preferredId)
 if(preferred)return preferred.entity
 const nearest=candidates[0]
 const previous=candidates.find(item=>item.entity.id===previousId)
 if(previous&&nearest&&previous.distance-nearest.distance<hysteresis)return previous.entity
 return nearest?.entity
}

/** Intent for the persistent action; map hotspots themselves only approach. */
export function primaryInteractionIntent(kind,panelOpen){
 if(panelOpen)return 'close-panel'
 if(!kind)return 'inactive'
 return kind==='door'?'enter-door':'open-panel'
}
