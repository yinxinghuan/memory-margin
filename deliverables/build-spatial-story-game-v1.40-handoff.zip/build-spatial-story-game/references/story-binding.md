# StoryCartridge 与空间绑定

把已有剧情接到地图壳，或给探索式创建器装配新内容时使用。`assets/spatial-binding.ts` 与 `assets/spatial-attachment.ts` 是无游戏内容、网络、存储和 renderer 依赖的源码，复制到目标游戏源码目录，由真实运行路径直接调用。

## 装配合同

1. 将实际 Cartridge 的 `id / initialMap / characters / domainRules.rules` 传给 `compileSpatialBinding`，将实际空间配置传给第二个参数。不要另写仅供校验的规则清单。第三个参数必须使用目标游戏的真实可行走判断。
2. `scenes.storyLocationId` 允许同一故事地点拥有多个房间；这时恢复、动作和转场必须显式携带物理场景 ID。`actionScope: 'scene'` 允许相同规则绑定不同场景实体，但同一场景不得存在两个目标。省略场景导致歧义时会拒绝，而不是猜选第一个房间或物件。
3. 每条领域规则必须有实体绑定。跨故事地点的 `map` 效果必须匹配对应 portal；同一故事地点内换房间也使用明确 portal，但无需伪造地点变化。
4. 当前场景的实体经过介绍/状态/资产许可后，再用 `admits(actionId,target,scene,position)` 检查接近条件。该函数只检查提供的坐标及距离；它不证明完整寻路、不验证角色已介绍、不验证图片，也不能将客户端坐标变成未来多人奖励的可信证明。
5. 唯一 Story Session 生成候选状态后、事务提交之前，调用 `assertTransition(before,after,actionId,currentScene)`。只采用其返回的已绑定落点。角色、物件状态、美术版本等表现准入仍由目标游戏额外验证；提交失败不得让 renderer 先走到下一场景。

字段和接口以两份源码的导出类型为准。物理角色 `travels: true` 可以每场景绑定一个实体；媒介角色可以绑定多处电台等设备，不因此取得物理占位。

## 旧档接入预检

`dryRunSpatialAttachment` 需要明确的已支持存档 schema、到达房间/坐标以及已准入场景和角色 ID。返回 `dry-run-ready` 时保留整个旧档，包括未知扩展字段、历史、任务与结局；候选是独立副本。返回 `not-ready` 时只给问题清单，候选为空。

预检不会迁移引擎、转换人物 ID、注册会话、绑定账号、上传存档或制造缺失素材。现有生产旧档导入还需独立的授权、幂等恢复和唯一写入者合同，不能把预检通过当成已经完成迁移。

## 独立复验

Node >=22.18，使用内置 TypeScript 转换，无需 npm 安装：

```sh
node --experimental-transform-types /path/to/skill/scripts/verify-story-binding.mjs
node --experimental-transform-types /path/to/skill/scripts/verify-story-binding.mjs /path/to/game/src/spatial-binding.ts /path/to/game/src/spatial-attachment.ts
```

7 个测试覆盖多房间共享地点、跨场景重复动作、明确 portal、接近拒绝、作者配置错误、不变性、完整旧档保留及缺素材/旧 schema 拒绝。测试使用纯数据样本，不创建游戏或服务，不替代实际 renderer 和平台验收。

来源：`rpgjs-story-lab` 提交 `b015485` 的同名源码；绑定编译器已由既有车厢与完整列车故事的运行路径消费。真实完整故事还执行了中英规则/地图匹配、120 条路线的实际碰撞配置抽样及一次原生 AlterU 完整路线。以上实证分别证明对应范围，不意味着这两份模块包含整套通用 Story Session 后台模板或完整生成资产生产线。
