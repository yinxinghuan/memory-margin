import assert from 'node:assert/strict'
import {pathToFileURL} from 'node:url'
import {resolve} from 'node:path'
const root=process.argv[2]?pathToFileURL(resolve(process.argv[2])+'/'):new URL('../assets/',import.meta.url)
const {findPath,walkable}=await import(new URL('world.ts',root))
const {deploymentScope}=await import(new URL('storage-scope.ts',root))
const {advanceRoute}=await import(new URL('distance-motion.ts',root))
const world={width:96,height:80,step:4,actor:{w:3,h:5},scenes:{room:{interior:{x:0,y:0,w:96,h:80},spawn:{x:5.5,y:9.25},obstacles:[{x:38,y:0,w:1,h:52}]}}}
let p={...world.scenes.room.spawn},target={x:70.3,y:12.5},route=findPath(world,'room',p,target),distance=0
assert.ok(route.length)
for(let n=0;n<2000&&route.length;n++){
 const r=advanceRoute(p,route,72/30,x=>walkable(world,'room',x));assert.equal(r.blocked,false);p=r.position;route.splice(0,r.consumed);distance+=r.distance
}
assert.equal(route.length,0);assert.ok(Math.hypot(p.x-target.x,p.y-target.y)<1e-7);assert.ok(distance>100)
world.scenes.room.obstacles[0].h=80
assert.deepEqual(findPath(world,'room',world.scenes.room.spawn,target),[])
assert.deepEqual(findPath(world,'missing',p,target),[])
assert.deepEqual(findPath(world,'room',{x:NaN,y:4},target),[])
const uuid='f3a37721-8aca-4a73-a4be-2c29de798376'
assert.equal(deploymentScope('source','game.aiwaves.tech',`/${uuid}/`),uuid)
assert.equal(deploymentScope('source','localhost','/'),'source')
assert.throws(()=>deploymentScope('source','game.aiwaves.tech','/bad/'))
console.log(JSON.stringify({passed:true,checks:['off-grid route around thin wall','distance consumption','sealed wall rejects','unknown scene rejects','nonfinite position rejects','URL namespace','local source namespace','invalid production namespace rejects']}))
