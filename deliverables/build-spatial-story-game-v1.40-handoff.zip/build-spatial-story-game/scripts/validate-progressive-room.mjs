#!/usr/bin/env node
import {readFileSync} from 'node:fs'
import {resolve} from 'node:path'

const input=process.argv[2]
if(!input){console.error('Usage: node validate-progressive-room.mjs ROOM-CONTRACT.json');process.exit(2)}
let contract
try{contract=JSON.parse(readFileSync(resolve(input),'utf8'))}catch(error){console.error(`Progressive room validation failed: ${error.message}`);process.exit(1)}
const issues=[]
const fail=message=>issues.push(message)
const object=value=>value&&typeof value==='object'&&!Array.isArray(value)
const finitePoint=value=>object(value)&&Number.isFinite(value.x)&&Number.isFinite(value.y)
const finiteRect=value=>finitePoint(value)&&Number.isFinite(value.w)&&Number.isFinite(value.h)&&value.w>0&&value.h>0
const stable=value=>JSON.stringify(value,Object.keys(value??{}).sort())
const index=(items,label)=>{
 const map=new Map()
 if(!Array.isArray(items)){fail(`${label} must be an array`);return map}
 for(const item of items){if(!object(item)||typeof item.id!=='string'||!item.id){fail(`${label} contains an item without a stable id`);continue}if(map.has(item.id))fail(`${label} repeats id ${item.id}`);map.set(item.id,item)}
 return map
}
if(contract?.version!==1)fail('version must be 1')
if(typeof contract?.sceneId!=='string'||!contract.sceneId)fail('sceneId is required')
for(const phase of ['shell','complete'])if(!object(contract?.[phase]))fail(`${phase} phase is required`)
if(object(contract?.shell)&&contract.shell.enterable!==true)fail('shell.enterable must be true')
if(object(contract?.shell)&&!finitePoint(contract.shell.spawn))fail('shell.spawn must be a finite point')
if(object(contract?.complete)&&!finitePoint(contract.complete.spawn))fail('complete.spawn must be a finite point')
if(finitePoint(contract?.shell?.spawn)&&finitePoint(contract?.complete?.spawn)&&stable(contract.shell.spawn)!==stable(contract.complete.spawn))fail('spawn changes between shell and complete')
const shellExits=index(contract?.shell?.exits,'shell.exits'),completeExits=index(contract?.complete?.exits,'complete.exits')
const shellSlots=index(contract?.shell?.slots,'shell.slots'),completeSlots=index(contract?.complete?.slots,'complete.slots')
const compare=(left,right,label,field,validator)=>{
 for(const [id,item] of left){const other=right.get(id);if(!other){fail(`${label} ${id} is missing from complete`);continue}if(!validator(item[field]))fail(`${label} ${id} has invalid ${field}`);if(stable(item[field])!==stable(other[field]))fail(`${label} ${id} changes ${field} between shell and complete`)}
 for(const id of right.keys())if(!left.has(id))fail(`${label} ${id} is missing from shell`)
}
compare(shellExits,completeExits,'exit','anchor',finitePoint)
compare(shellSlots,completeSlots,'slot','footprint',finiteRect)
const collectStrings=value=>typeof value==='string'?[value]:object(value)?Object.values(value).flatMap(collectStrings):[]
const copy=collectStrings(contract?.shell?.playerCopy)
if(!copy.length||copy.some(text=>!text.trim()))fail('shell.playerCopy must contain non-empty player-facing status and hint text')
const internal=/碰撞|路线|占地|媒体|任务队列|后台|坐标|画布|测速|请求编号|collision|route|footprint|media task|task queue|background job|coordinate|canvas size|benchmark|request[_ -]?id/i
for(const text of copy)if(internal.test(text))fail(`player copy exposes implementation detail: ${text}`)
if(issues.length){for(const issue of issues)console.error(`FAIL: ${issue}`);process.exit(1)}
console.log(JSON.stringify({passed:true,sceneId:contract.sceneId,slots:shellSlots.size,exits:shellExits.size}))
