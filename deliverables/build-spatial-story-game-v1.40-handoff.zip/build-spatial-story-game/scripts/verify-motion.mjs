// Node >=22.18: built-in TypeScript stripping; no npm install or game imports.
import { test } from 'node:test'
import assert from 'node:assert/strict'
import { pathToFileURL } from 'node:url'
import { resolve } from 'node:path'
const source=process.argv[2]?pathToFileURL(resolve(process.argv[2])):new URL('../assets/distance-motion.ts',import.meta.url)
const {advanceRoute,moveWithCollision,createDistancePoseSelector}=await import(source.href)
const near=(actual,expected)=>assert.ok(Math.abs(actual-expected)<1e-6,`${actual} != ${expected}`)

for(const fps of [30,60,120])test(`independent room and custom gait at ${fps}fps`,()=>{
 const pose=createDistancePoseSelector(24,['heel-left','center','heel-right','center'])
 let position={x:12,y:12},route=Array.from({length:81},(_,i)=>({x:12,y:12+i*3})),distance=0
 const seen=new Set()
 for(let frame=0;frame<fps;frame++){
  const result=advanceRoute(position,route,72/fps,()=>true)
  near(result.distance,72/fps)
  position=result.position;route=route.slice(result.consumed);distance+=result.distance
  seen.add(pose(distance))
 }
 near(position.y,84);near(distance,72);assert.equal(seen.size,3)
})
test('custom strides and slow input have matching poses at matching distances',()=>{
 for(const stride of [12,24,80]){
  const pose=createDistancePoseSelector(stride,['a','b','c','d'])
  assert.deepEqual([0,1,2,3,4].map(i=>pose(stride*i/4)),['a','b','c','d','a'])
  assert.equal(pose(stride*.3),pose(stride*2.3))
 }
 const travel=(delta,count)=>{
  let position={x:0,y:0},distance=0
  for(let i=0;i<count;i++){const r=moveWithCollision(position,{x:delta,y:0},()=>true);position=r.position;distance+=r.distance}
  return distance
 }
 near(travel(.25,24),travel(1,6))
})
test('irregular frames consume corners continuously and do not mutate the caller route',()=>{
 let position={x:0,y:0},route=Object.freeze([{x:0,y:0},{x:0,y:3},{x:3,y:3},{x:120,y:3}].map(Object.freeze)),distance=0
 const before=JSON.stringify(route)
 let remaining=route
 for(const dt of [.008,.033,.016,.04,.009,.027]){
  const r=advanceRoute(position,remaining,72*dt,()=>true)
  near(r.distance,72*dt);position=r.position;remaining=remaining.slice(r.consumed);distance+=r.distance
 }
 near(distance,72*.133);near(position.x,distance-3);near(position.y,3)
 assert.equal(JSON.stringify(route),before)
})
test('arrival does not overshoot and zero budget never moves',()=>{
 const route=[{x:0,y:0},{x:0,y:1},{x:0,y:2}]
 const r=advanceRoute({x:0,y:0},route,10,()=>true)
 assert.equal(r.arrived,true);assert.equal(r.consumed,3);near(r.distance,2);near(r.position.y,2)
 const stop=advanceRoute({x:0,y:0},route,0,()=>true)
 near(stop.distance,0);near(stop.position.y,0);assert.equal(stop.arrived,false)
})
test('wall contact cannot advance gait; wall sliding uses actual travel',()=>{
 const wall=p=>p.x<=0
 near(moveWithCollision({x:0,y:0},{x:4,y:0},wall).distance,0)
 near(moveWithCollision({x:0,y:0},{x:4,y:3},wall).distance,3)
 const r=advanceRoute({x:0,y:0},[{x:4,y:0}],4,wall)
 assert.equal(r.blocked,true);assert.equal(r.arrived,false)
})
test('one-unit sweep detects thin barriers despite a large frame delta',()=>{
 const r=moveWithCollision({x:0,y:0},{x:10,y:0},p=>p.x<2||p.x>3)
 assert.ok(r.position.x<2)
})
test('pose cycle is owned by the selector and invalid calibration fails explicitly',()=>{
 const names=['a','b'],pose=createDistancePoseSelector(12,names)
 names[0]='changed';assert.equal(pose(0),'a')
 for(const stride of [0,-1,Infinity,NaN])assert.throws(()=>createDistancePoseSelector(stride,['a']))
 assert.throws(()=>createDistancePoseSelector(12,[]))
 for(const distance of [-1,Infinity,NaN])assert.throws(()=>pose(distance))
})
